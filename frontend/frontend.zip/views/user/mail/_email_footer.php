<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
use yii\helpers\Url;

?>

      
          <p style="text-align: center;">Powered by:  Unserplan-B <br/>
              
                      <a class="navbar-brand" href="<?= Yii::$app->urlManager->createUrl("/") ?>" style="text-decoration:none"><img src="https://unserplan-b.de/<?= Url::base().'/images/web/logo.png'; ?>" style="max-width: 50px;"></a>

              <!--<small ><a href="https://smart-codes.eu/">Developed by Smart Codes e.U.</a></small>-->
          </p>
  
