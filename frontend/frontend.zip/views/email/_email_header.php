<?php
use yii\helpers\Url;

?>

<body style="margin: 0; padding: 0;">

<div style="text-align: center;">
        <a class="navbar-brand" href="<?= Yii::$app->urlManager->createUrl("/") ?>" style="max-width: 50 px;text-decoration:none">
            <img src="<?= imageURL('logo.png') ?>" style="max-width: 216px;">
        </a>
</div>
