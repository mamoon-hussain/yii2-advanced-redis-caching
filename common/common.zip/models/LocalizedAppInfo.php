<?php

namespace common\models;

use common\enums\Constents;
use common\models\Product;
use Yii;


class LocalizedAppInfo extends \common\models\generated\LocalizedAppInfo
{



}
