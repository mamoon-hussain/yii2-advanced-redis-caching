<?php

namespace common\models\search;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\PlaceContents;

/**
 * PlaceContentsSearch represents the model behind the search form of `common\models\PlaceContents`.
 */
class PlaceContentsSearch extends \common\models\generated\search\PlaceContentsSearch
{

}
