<?php

namespace common\models;

use common\enums\Constents;
use common\models\Product;
use Yii;


class LocalizedPlace extends \common\models\generated\LocalizedPlace
{



}
