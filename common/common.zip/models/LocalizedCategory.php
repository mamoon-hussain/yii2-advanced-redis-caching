<?php

namespace common\models;

use common\enums\Constents;
use common\models\Product;
use Yii;


class LocalizedCategory extends \common\models\generated\LocalizedCategory
{



}
