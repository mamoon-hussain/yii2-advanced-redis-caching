<?php

namespace common\models;

use common\enums\Constents;
use common\models\Product;
use Yii;


class LocalizedPlaceContents extends \common\models\generated\LocalizedPlaceContents
{



}
