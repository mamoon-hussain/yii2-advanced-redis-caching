<?php

namespace backend\user\controllers;

use yii\data\ActiveDataProvider;

class AuthController extends \webvimark\modules\UserManagement\controllers\AuthController {


}
